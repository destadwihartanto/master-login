<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>SIBIMBE</title>
	<!-- plugins:css -->
	<link rel="stylesheet" href="<?= base_url('login/'); ?>vendors/mdi/css/materialdesignicons.min.css">
	<link rel="stylesheet" href="<?= base_url('login/'); ?>vendors/css/vendor.bundle.base.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	<!-- endinject -->
	<!-- Plugin css for this page -->
	<!-- End plugin css for this page -->
	<!-- Layout styles -->
	<link rel="stylesheet" href="<?= base_url('login/'); ?>css/demo/style.css">
	<!-- End layout styles -->
	<link rel="shortcut icon" href="<?= base_url('login/'); ?>images/favicon.png" />
</head>

<body>
